package GRA;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Pocisk extends Główny implements ActionListener{
	 private final int BOARD_WIDTH = 890;
	    private final int POCISK_SPEED = 2;
	    Boolean zmienna = false;
	    Panel2 panel2;
	    public Color kolor;

	    public Pocisk(int x, int y) {
	        super(x, y);
	       
	        initPocisk();
	    }
	   
	    public void initPocisk() {
	       
	        loadImage("ee.png");
	        getImageDimensions();
	    	
	    }

	    public void move() {
	        
	        x += POCISK_SPEED;
	        
	        if (x > BOARD_WIDTH)
	            visible = false;
	    }

		@Override
		public void actionPerformed(ActionEvent e) {
		
			
		}

}
