package GRA;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Panel2 extends JPanel implements ActionListener{
	Pocisk pocisk;
	
	
	Panel2(){
		ImageIcon LicznikHPiEnergii = new ImageIcon("HP2.png");
		ImageIcon Bron1 = new ImageIcon("Gun1.png");
		ImageIcon Bron2 = new ImageIcon("Gun1.png");
		ImageIcon Bron3 = new ImageIcon("Gun1.png");
		ImageIcon WyborNogi = new ImageIcon("Nogi.png");
		ImageIcon WyborBrzuch = new ImageIcon("Brzuch.png");
		ImageIcon WyborGlowa = new ImageIcon("Glowa.png");
		
		JButton CelNogi = new JButton (WyborNogi);
    	JButton CelBrzuch = new JButton (WyborBrzuch);
    	JButton CelGlowa = new JButton (WyborGlowa);
    	JButton BronPierwsza = new JButton(Bron1);
    	JButton BronDruga= new JButton(Bron2);
    	JButton BronTrzecia = new JButton(Bron3);
    	JLabel HP = new JLabel(LicznikHPiEnergii);
		
		add(CelNogi);
    	add(CelBrzuch);
    	add(CelGlowa);
    	add(BronPierwsza);
    	add(BronDruga);
    	add(BronTrzecia);
    	add(HP);
    	
    	setBackground(Color.BLACK);
    	
    	HP.setBackground(Color.BLACK);
		HP.setOpaque(true);
		
		BronPierwsza.setBackground(Color.BLACK);
		BronPierwsza.setOpaque(true);
		BronPierwsza.setBorderPainted(false);
		
		BronDruga.setBackground(Color.BLACK);
		BronDruga.setOpaque(true);
		BronDruga.setBorderPainted(false);
		
		BronTrzecia.setBackground(Color.BLACK);
		BronTrzecia.setOpaque(true);
		BronTrzecia.setBorderPainted(false);
		
		CelNogi.setBackground(Color.BLACK);
		CelNogi.setOpaque(true);
		CelNogi.setBorderPainted(false);
		
		CelBrzuch.setBackground(Color.BLACK);
		CelBrzuch.setOpaque(true);
		CelBrzuch.setBorderPainted(false);
		
		CelGlowa.setBackground(Color.BLACK);
		CelGlowa.setOpaque(true);
		CelGlowa.setBorderPainted(false);
		
		BronPierwsza.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				pocisk.isVisible();
				
			}
			
		});
		BronDruga.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				
			}
			
		});
		BronTrzecia.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
			
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
