package GRA;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;

public class Okno1 extends JFrame implements ActionListener, MouseListener, MouseMotionListener, LineListener{
	static JTextPane tekst;
	JPanel panel2;
	JPanel panel5;
	JButton nowa_gra;
	JButton wczytaj;
	JButton dzwiek;
	JButton jezyk;
	JButton wyjdz;
	JButton lenguage;
	String audioFilePath = "";
	Clip audioClip = null;
	File audioFile = null;
	AudioInputStream audioStream = null;
	Thread thread;
	
	boolean playCompleted = false;
	
	public Okno1 (){
		//wczytuje obrazki 
		ImageIcon nowaGra = new ImageIcon("nowaGra.png");
		ImageIcon wczyt = new ImageIcon("wczytaj.png");
		ImageIcon dzwie = new ImageIcon("dzwiek.png");
		ImageIcon jezykk = new ImageIcon("jezyk.png");
		ImageIcon wyjscie = new ImageIcon("wyjdz.png");
		ImageIcon name = new ImageIcon("spacedarkness2.png");
		ImageIcon newGame = new ImageIcon("newgame.png");
		ImageIcon load = new ImageIcon("load.png");
		ImageIcon sound = new ImageIcon("sound.png");
		ImageIcon language = new ImageIcon("language.png");
		ImageIcon exit = new ImageIcon("exit.png");
		
	    this.setSize(800, 600);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		//Tworzenie paneli i ustawianie ich 
		JPanel panel1 = new JPanel(new FlowLayout());
		add(BorderLayout.NORTH, panel1);
		panel2 = new JPanel(new GridLayout(5,1));
		add(BorderLayout.CENTER, panel2);
		panel2.setSize(1345, 350);
		JPanel panel3 = new JPanel();
		add(BorderLayout.WEST, panel3);
		JPanel panel4 = new JPanel();
		add(BorderLayout.EAST,panel4);
		
		//Tworzenie przycisków
		JLabel nazwa = new JLabel (name);
		nowa_gra = new JButton (nowaGra);
		wczytaj = new JButton (wczyt);
		dzwiek = new JButton (dzwie);
		jezyk = new JButton (jezykk);
		wyjdz = new JButton (wyjscie);
		
		nazwa.setSize(638, 147);
		nowa_gra.setSize(269, 70);
		wczytaj.setSize(269, 70);
		dzwiek.setSize(269, 70);
		jezyk.setSize(269, 70);
		wyjdz.setSize(269, 70);
		
		//kolor tła paneli
		panel1.setBackground(Color.BLACK);
		panel2.setBackground(Color.BLACK);
		panel3.setBackground(Color.BLACK);
		panel4.setBackground(Color.BLACK);
		
		//kolor tła przycisków
		nowa_gra.setBackground(Color.BLACK);
		nowa_gra.setOpaque(true);
		nowa_gra.setBorderPainted(false);
		
		wczytaj.setBackground(Color.BLACK);
		wczytaj.setOpaque(true);
		wczytaj.setBorderPainted(false);
		
		dzwiek.setBackground(Color.BLACK);
		dzwiek.setOpaque(true);
		dzwiek.setBorderPainted(false);
		
		jezyk.setBackground(Color.BLACK);
		jezyk.setOpaque(true);
		jezyk.setBorderPainted(false);
		
		wyjdz.setBackground(Color.BLACK);
		wyjdz.setOpaque(true);
		wyjdz.setBorderPainted(false);
		
		nazwa.setBackground(Color.BLACK);
		nazwa.setOpaque(true);
		
		panel1.add(nazwa);
		panel2.add(nowa_gra);
		panel2.add(wczytaj);
		panel2.add(dzwiek); 
		panel2.add(jezyk);
		panel2.add(wyjdz);
		
		wyjdz.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				wyjdz();
				
			}
		 
		});
		
		wczytaj.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				wczytaj();
				
			}
		});
		nowa_gra.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				nowa_gra();
				
			}
			
		});
		jezyk.addMouseListener(this);
		jezyk.addMouseMotionListener(this);
		
		dzwiek.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(audioClip != null) {
					audioClip.stop();
				}
				else{
					audioClip.start();
				}
				
			}
    		
    	});
		
	}
	

public void nowa_gra() {
	Okno2 ok2 = new Okno2();
	ok2.setVisible(true);
}

public void wczytaj() {
	FileReader fr = null;
	String s ="";

	// OTWIERANIE PLIKU:
	try {
		fr = new FileReader("plik.txt");
		BufferedReader bfr = new BufferedReader(fr);
		//Scanner in = new Scanner(fr);
	//	String zadanie = in.nextLine();
	//	System.out.println(zadanie);

		// ODCZYT KOLEJNYCH LINII Z PLIKU:
		while ((s = bfr.readLine()) != null) {
			System.out.println(s);
			
			tekst.setText(tekst.getText()+"\n"+s);
		}
		
		

		// ZAMYKANIE PLIKU
		fr.close();
	} catch (Exception e) {
		System.out.println("BLAD IO!");
		System.exit(1);
	}
	
}

public void wyjdz() {
	System.exit(0);
}
void play(String audioFilePath) {
	
    try {
        audioFile = new File(audioFilePath);
        audioStream = AudioSystem.getAudioInputStream(audioFile);
        AudioFormat format = audioStream.getFormat();
        DataLine.Info info = new DataLine.Info(Clip.class, format);
        audioClip = (Clip) AudioSystem.getLine(info);
        audioClip.addLineListener(this);
        audioClip.open(audioStream);
        
        /**
         *  Play the audio clip in a new thread not to block the GUI.
         *  It helps in this case, but is not really necessary. 
         */
        thread = new Thread(new Runnable() {

            public void run() {
            	 audioClip.start();
 	            while(!playCompleted){          	
 	            	    	            	
 	            }
 	            audioClip.close();

 	            try {
						audioStream.close();
					} catch (IOException e) {
				            e.printStackTrace();
					}
                        
            }
                    
        });
        thread.start();
        
        

    } catch (UnsupportedAudioFileException ex) {
        System.out.println("The specified audio file is not supported.");
        ex.printStackTrace();
    } catch (LineUnavailableException ex) {
        System.out.println("Audio line for playing back is unavailable.");
        ex.printStackTrace();
    } catch (IOException e1) {
        System.out.println("Error playing the audio file.");
		e1.printStackTrace();
	} 
     
}

 
/**
 * Listens to the START and STOP events of the audio line.
 */
@Override
public void update(LineEvent event) {
    LineEvent.Type type = event.getType();
     
    if (type == LineEvent.Type.START) {
        System.out.println("Playback started.");
         
    } else if (type == LineEvent.Type.STOP) {
        playCompleted = true;
        System.out.println("Playback completed.");
    }

}




	public static void main(String[] args) {
		final String inFileName = "Nick Cave -320 (online-audio-converter.com).wav";
		 EventQueue.invokeLater(() -> {
	          Okno1 ok1 = new Okno1();
	          ok1.setVisible(true);
	          ok1.play(inFileName);
		 });
		
}


	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (e.getClickCount() == 1) {
			ImageIcon newGame = new ImageIcon("newgame.png");
			ImageIcon load = new ImageIcon("load.png");
			ImageIcon sound = new ImageIcon("sound.png");
			ImageIcon language = new ImageIcon("language.png");
			ImageIcon exit = new ImageIcon("exit.png");
			
			
			nowa_gra.setIcon(newGame);
			wczytaj.setIcon(load);
			dzwiek.setIcon(sound);
			jezyk.setIcon(language);
			wyjdz.setIcon(exit);
		}
		else if (e.getClickCount() == 2) {
			ImageIcon nowaGra = new ImageIcon("nowaGra.png");
			ImageIcon wczyt = new ImageIcon("wczytaj.png");
			ImageIcon dzwie = new ImageIcon("dzwiek.png");
			ImageIcon jezykk = new ImageIcon("jezyk.png");
			ImageIcon wyjscie = new ImageIcon("wyjdz.png");
			nowa_gra.setIcon(nowaGra);
			wczytaj.setIcon(wczyt);
			dzwiek.setIcon(dzwie);
			jezyk.setIcon(jezykk);
			wyjdz.setIcon(wyjscie);
			    }
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
