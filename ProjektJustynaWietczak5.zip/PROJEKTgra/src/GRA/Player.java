package GRA;

import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;


public class Player extends Główny{
	    public int dx;
	    public int dy;
	    private List<Pocisk> pocisk;
	    public boolean go_right, go_down;
	    public int sign, sign2;

	    public Player(int x, int y) {
	        super(x, y);

	        initCraft();
	    }

	    private void initCraft() {
	        
	        pocisk = new ArrayList<>();
	        loadImage("dd.png");
	        getImageDimensions();
	    }

	    public void move() {

	    	 if (x >= 20) {
	              go_right = false;
	          }
	          if (x <= 40) {
	              go_right = true;
	          }
	          if (y >= 40) {
	              go_down = false;
	          }
	          if (y <= 20) {
	              go_down = true;
	          }
	          sign = go_right ? 1 : -1;
	          sign2 = go_down ? 0 : 0;
	          x += 0 * sign;
	          y += 0 * sign2;
	    }

	    public List<Pocisk> getPocisk() {
	        return pocisk;
	    }
	   
	 
	    //to nadaje pociskowi siłe
	    public void fire() {
	        pocisk.add(new Pocisk(x + width, y + height / 2));
	    }
	    
	   

	    public void keyReleased(KeyEvent e) {

	        int key = e.getKeyCode();

	        if (key == KeyEvent.VK_LEFT) {
	            dx = 0;
	        }

	        if (key == KeyEvent.VK_RIGHT) {
	            dx = 0;
	        }

	        if (key == KeyEvent.VK_UP) {
	            dy = 0;
	        }

	        if (key == KeyEvent.VK_DOWN) {
	            dy = 0;
	        }
	    }

}
