package GRA;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.Timer;



public class PanelGry extends JPanel implements ActionListener{
	    public Timer timer;
	    private Player player;
	    private List<Alien> aliens;
	    private boolean ingame;
	    private final int ICRAFT_X = 40;
	    private final int ICRAFT_Y = 60;
	    private final int B_WIDTH = 900;
	    private final int B_HEIGHT = 600;
	    private final int DELAY = 15;
	    public int x = 450, y = 300;
	    public Color color = Color.RED;

	    private final int[][] pos = {
	        {280, 29}, {250, 59}, {138, 89},
	        {940, 59}, {990, 30}, {920, 200},
	        {820, 128}, {490, 170}, {700, 30}
	    };

	    public PanelGry() {

	        initPanelGry();
	    }

	    private void initPanelGry() {

	      //  this.addKeyListener(new TAdapter());
	        MyMouseListener listener = new MyMouseListener();
	        addMouseListener(listener);
	        setFocusable(true);
	        setBackground(Color.BLACK);
	        ingame = true;

	        setPreferredSize(new Dimension(B_WIDTH, B_HEIGHT));

	        player = new Player(ICRAFT_X, ICRAFT_Y);

	        initAliens();

	        timer = new Timer(DELAY, this);
	        timer.start();
	    }
	    
	    class MyMouseListener extends MouseAdapter {
	          
	          public void mousePressed(MouseEvent e) {
	             player.x = e.getX();
	             player.y = e.getY();
	          }
	          public void mouseReleased(MouseEvent e) {
	              repaint();
	          }
	          public void mouseClicked(MouseEvent e) {
	        	  player.fire();
	          } 
	      }
	    public void initAliens() {
	        
	        aliens = new ArrayList<>();

	        for (int[] p : pos) {
	            aliens.add(new Alien(p[0], p[1]));
	        }
	    }

	    @Override
	    public void paintComponent(Graphics g) {
	        super.paintComponent(g);

	        if (ingame) {

	            drawObjects(g);

	        } else {

	            drawGameOver(g);
	        }

	        Toolkit.getDefaultToolkit().sync();
	    }

	    private void drawObjects(Graphics g) {

	        if (player.isVisible()) {
	            g.drawImage(player.getImage(), player.getX(), player.getY(),
	                    this);
	        }

	        List<Pocisk> ps = player.getPocisk();

	        for (Pocisk pocisk : ps) {
	            if (pocisk.isVisible()) {   	
	                g.drawImage(pocisk.getImage(), pocisk.getX(), 
	                        pocisk.getY(), this);
	            }
	        }
	        

	        for (Alien alien : aliens) {
	            if (alien.isVisible()) {
	                g.drawImage(alien.getImage(), alien.getX(), alien.getY(), this);
	            }
	        }

	        g.setColor(Color.WHITE);
	        g.drawString("Aliens left: " + aliens.size(), 5, 15);
	    }

	    private void drawGameOver(Graphics g) {

	        String msg = "Game Over";
	        Font small = new Font("Helvetica", Font.BOLD, 14);
	        FontMetrics fm = getFontMetrics(small);

	        g.setColor(Color.white);
	        g.setFont(small);
	        g.drawString(msg, (B_WIDTH - fm.stringWidth(msg)) / 2,
	                B_HEIGHT / 2);
	    }
	   

	    @Override
	    public void actionPerformed(ActionEvent e) {

	        inGame();

	        updateShip();
	        updatePocisk();
	        updateAliens();

	        checkCollisions();

	        repaint();
	    }

	    private void inGame() {

	        if (!ingame) {
	            timer.stop();
	        }
	    }

	    private void updateShip() {

	        if (player.isVisible()) {
	            
	            player.move();
	        }
	    }

	    private void updatePocisk() {

	        List<Pocisk> ps = player.getPocisk();

	        for (int i = 0; i < ps.size(); i++) {

	            Pocisk p = ps.get(i);

	            if (p.isVisible()) {
	                p.move();
	            } else {
	                ps.remove(i);
	            }
	        }
	    }

	    private void updateAliens() {

	        if (aliens.isEmpty()) {

	            ingame = false;
	            return;
	        }

	        for (int i = 0; i < aliens.size(); i++) {

	            Alien a = aliens.get(i);
	            
	            if (a.isVisible()) {
	                a.move();
	            } else {
	                aliens.remove(i);
	            }
	        }
	    }

	    public void checkCollisions() {

	        Rectangle r3 = player.getBounds();

	        for (Alien alien : aliens) {
	            
	            Rectangle r2 = alien.getBounds();

	            if (r3.intersects(r2)) {
	                
	                player.setVisible(false);
	                alien.setVisible(false);
	                ingame = false;
	            }
	        }

	        List<Pocisk> ps = player.getPocisk();

	        for (Pocisk p : ps) {

	            Rectangle r1 = p.getBounds();

	            for (Alien alien : aliens) {

	                Rectangle r2 = alien.getBounds();

	                if (r1.intersects(r2)) {
	                    
	                    p.setVisible(false);
	                    alien.setVisible(false);
	                }
	            }
	        }
	    }

	  /*  private class TAdapter extends KeyAdapter {

	        @Override
	        public void keyReleased(KeyEvent e) {
	            player.keyReleased(e);
	        }

	        @Override
	        public void keyPressed(KeyEvent e) {
	            player.keyPressed(e);
	        }
	    }*/

}
