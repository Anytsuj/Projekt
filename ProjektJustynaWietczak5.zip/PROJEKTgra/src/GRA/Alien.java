package GRA;


public class Alien extends Główny{
	 private final int INITIAL_Y = 600;
	 public boolean go_right, go_down;
	 public int sign, sign2;

	    public Alien(int x, int y) {
	        super(x, y);

	        initAlien();
	    }

	    private void initAlien() {

	        loadImage("ccc.png");
	        getImageDimensions();
	    }

	    public void move() {

	    	
	          if (y >= 540) {
	              go_down = false;
	          }
	          if (y <= 40) {
	              go_down = true;
	          }
	       
	          sign2 = go_down ? 1 : -1;
	        
	          y += 5 * sign2;
	      }
}
