package GRA;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import javax.swing.JFrame;



public class Okno2 extends JFrame{
	
	
	
	boolean playCompleted = false;
	
	public Okno2() {
	        
	        initUI();
	    }
	    
	    private void initUI() {
	        
	       this.setLayout(new BorderLayout());
		   this.add(new PanelGry(),BorderLayout.CENTER );  
		   this.add(new Panel2(),BorderLayout.SOUTH);
		   this.add(new Panel3(), BorderLayout.WEST);
		   
	        setResizable(false);
	        pack();
	        
	        setTitle("SpaceDarkness");
	        setLocationRelativeTo(null);
	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	       
			
	    }
	    

	    public static void main(String[] args) {
	    	
	        EventQueue.invokeLater(() -> {
	            Okno2 ok2 = new Okno2();
	            ok2.setVisible(true);
	           
	        });
	    }

}
