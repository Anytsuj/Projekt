package GRA;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextPane;


public class Panel3 extends JPanel implements ActionListener{
	PanelGry panGry;
	Okno2 ok2;
	static JTextPane test;
	
	Panel3(){
		setLayout(new GridLayout(4,1));
		ImageIcon Zapisz = new ImageIcon("IkonaZapis.png");
		ImageIcon Wycisz = new ImageIcon("IkonaDzwiek.png");
		ImageIcon PominTure = new ImageIcon("Pomin.png");
		ImageIcon WyjsciezGry = new ImageIcon("IkonaWyjscie.png");
		
		JButton Zapis = new JButton(Zapisz);
    	JButton Dzwiek = new JButton(Wycisz);
    	JButton Wyjscie = new JButton(WyjsciezGry);
    	JButton Pomin = new JButton(PominTure);
    	
    	Zapis.setBackground(Color.BLACK);
		Zapis.setOpaque(true);
		Zapis.setBorderPainted(false);
		
		Dzwiek.setBackground(Color.BLACK);
		Dzwiek.setOpaque(true);
		Dzwiek.setBorderPainted(false);
		
		Wyjscie.setBackground(Color.BLACK);
		Wyjscie.setOpaque(true);
		Wyjscie.setBorderPainted(false);
		
		Pomin.setBackground(Color.BLACK);
		Pomin.setOpaque(true);
		Pomin.setBorderPainted(false);
		
		setBackground(Color.BLACK);
		
	    add(Zapis);
    	add(Dzwiek);
    	add(Wyjscie);
    	add(Pomin);
    	
    	Zapis.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				 zapis();
				
			}
    		
    	});
    	
    	Pomin.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				panGry.timer.stop();
				
			}
    		
    	});
    	
    	Wyjscie.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Wyjscie();
				}
			
		});
    	
    	Dzwiek.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
			}
			}); 
		
	}
	
	 public static void Wyjscie() {
		   System.exit(0);
	   }
	 
	
	    
	    public static void zapis() {
			
			String s = test.getText();

			FileWriter fw = null;

			try {
				fw = new FileWriter("plik.txt");
				BufferedWriter bw = new BufferedWriter(fw);

			
					bw.write(s);

				bw.close();
				//fw.close(); - wystarczy zamknąć zewnętrzny
			} catch (IOException e) {
				e.printStackTrace();
			
		}
		}
	    
	    

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
